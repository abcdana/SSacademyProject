package com.project.dto;

public class GetJobInfoDTO {
	
	private String seqGetJobInfo;
	private String seqRegCourse;
	private String location;
	private String name;
	private String duty;
	private String salary;
	private String form;
	private String getJobDate;
	
	public String getSeqGetJobInfo() {
		return seqGetJobInfo;
	}
	public void setSeqGetJobInfo(String seqGetJobInfo) {
		this.seqGetJobInfo = seqGetJobInfo;
	}
	public String getSeqRegCourse() {
		return seqRegCourse;
	}
	public void setSeqRegCourse(String seqRegCourse) {
		this.seqRegCourse = seqRegCourse;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDuty() {
		return duty;
	}
	public void setDuty(String duty) {
		this.duty = duty;
	}
	public String getSalary() {
		return salary;
	}
	public void setSalary(String salary) {
		this.salary = salary;
	}
	public String getForm() {
		return form;
	}
	public void setForm(String form) {
		this.form = form;
	}
	public String getGetJobDate() {
		return getJobDate;
	}
	public void setGetJobDate(String getJobDate) {
		this.getJobDate = getJobDate;
	}

}
