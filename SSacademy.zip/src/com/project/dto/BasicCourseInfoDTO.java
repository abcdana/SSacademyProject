package com.project.dto;

public class BasicCourseInfoDTO {
	
	private String seqBasicCourseInfo;
	private String name;
	private String period;
	private String info;
	
	public String getSeqBasicCourseInfo() {
		return seqBasicCourseInfo;
	}
	public void setSeqBasicCourseInfo(String seqBasicCourseInfo) {
		this.seqBasicCourseInfo = seqBasicCourseInfo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPeriod() {
		return period;
	}
	public void setPeriod(String period) {
		this.period = period;
	}
	public String getInfo() {
		return info;
	}
	public void setInfo(String info) {
		this.info = info;
	}

}
