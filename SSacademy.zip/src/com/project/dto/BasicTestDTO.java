package com.project.dto;

public class BasicTestDTO {

	private String seqBasicTest;
	private String seqOpenSubject;
	private String question;
	private String questionNum;
	
	public String getSeqOpenSubject() {
		return seqOpenSubject;
	}
	public void setSeqOpenSubject(String seqOpenSubject) {
		this.seqOpenSubject = seqOpenSubject;
	}
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public String getQuestionNum() {
		return questionNum;
	}
	public void setQuestionNum(String questionNum) {
		this.questionNum = questionNum;
	}
	public String getSeqBasicTest() {
		return seqBasicTest;
	}
	public void setSeqBasicTest(String seqBasicTest) {
		this.seqBasicTest = seqBasicTest;
	}
}
