package com.project.dto;

public class RoomDTO {

	private String seqRoom;
	private String name;
	private String people;
	
	public String getSeqRoom() {
		return seqRoom;
	}
	public void setSeqRoom(String seqRoom) {
		this.seqRoom = seqRoom;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPeople() {
		return people;
	}
	public void setPeople(String people) {
		this.people = people;
	}
	
}
