package com.project.dto;

public class CourseSubjectDTO {

	private String seqCourseSubject;
	private String seqBasicCourseInfo;
	private String seqBasicSubject;
	

	public String getSeqCourseSubject() {
		return seqCourseSubject;
	}
	public void setSeqCourseSubject(String seqCourseSubject) {
		this.seqCourseSubject = seqCourseSubject;
	}
	public String getSeqBasicCourseInfo() {
		return seqBasicCourseInfo;
	}
	public void setSeqBasicCourseInfo(String seqBasicCourseInfo) {
		this.seqBasicCourseInfo = seqBasicCourseInfo;
	}
	public String getSeqBasicSubject() {
		return seqBasicSubject;
	}
	public void setSeqBasicSubject(String seqBasicSubject) {
		this.seqBasicSubject = seqBasicSubject;
	}

	
}

