package com.project.dto;

public class VwSubjectInquiryDTO {
	
	private String subSeq;     
	private String tSeq;    
	private String courseName;
	private String courseStart;     
	private String courseEnd;      
	private String roomName;
	private String subName;
	private String subStart;        
	private String subEnd;      
	private String bookName;
	
	public String getSubSeq() {
		return subSeq;
	}
	public void setSubSeq(String subSeq) {
		this.subSeq = subSeq;
	}
	public String gettSeq() {
		return tSeq;
	}
	public void settSeq(String tSeq) {
		this.tSeq = tSeq;
	}
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	public String getCourseStart() {
		return courseStart;
	}
	public void setCourseStart(String courseStart) {
		this.courseStart = courseStart;
	}
	public String getCourseEnd() {
		return courseEnd;
	}
	public void setCourseEnd(String courseEnd) {
		this.courseEnd = courseEnd;
	}
	public String getRoomName() {
		return roomName;
	}
	public void setRoomName(String roomName) {
		this.roomName = roomName;
	}
	public String getSubName() {
		return subName;
	}
	public void setSubName(String subName) {
		this.subName = subName;
	}
	public String getSubStart() {
		return subStart;
	}
	public void setSubStart(String subStart) {
		this.subStart = subStart;
	}
	public String getSubEnd() {
		return subEnd;
	}
	public void setSubEnd(String subEnd) {
		this.subEnd = subEnd;
	}
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	
	

}
