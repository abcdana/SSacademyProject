package com.project.teacher.dto;

public class ProcScoreUpdateDTO {

	private String subnum;
	private String stunum;
	private String wnum;
	private String pnum;
	private String anum;
	
	
	public String getSubnum() {
		return subnum;
	}
	public void setSubnum(String subnum) {
		this.subnum = subnum;
	}
	public String getStunum() {
		return stunum;
	}
	public void setStunum(String stunum) {
		this.stunum = stunum;
	}
	public String getWnum() {
		return wnum;
	}
	public void setWnum(String wnum) {
		this.wnum = wnum;
	}
	public String getPnum() {
		return pnum;
	}
	public void setPnum(String pnum) {
		this.pnum = pnum;
	}
	public String getAnum() {
		return anum;
	}
	public void setAnum(String anum) {
		this.anum = anum;
	}
	
}
