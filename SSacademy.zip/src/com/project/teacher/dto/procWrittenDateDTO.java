package com.project.teacher.dto;

public class procWrittenDateDTO {
	private String subnum;
	private String wdate;
	
	public String getSubnum() {
		return subnum;
	}
	public void setSubnum(String subnum) {
		this.subnum = subnum;
	}
	public String getWdate() {
		return wdate;
	}
	public void setWdate(String wdate) {
		this.wdate = wdate;
	}
	
	

}
