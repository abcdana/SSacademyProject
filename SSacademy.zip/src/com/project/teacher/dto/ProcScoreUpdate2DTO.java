package com.project.teacher.dto;

public class ProcScoreUpdate2DTO {

	private String testnum;
	private String wnum;
	private String pnum;
	private String anum;
	
	
	public String getTestnum() {
		return testnum;
	}
	public void setTestnum(String testnum) {
		this.testnum = testnum;
	}
	public String getWnum() {
		return wnum;
	}
	public void setWnum(String wnum) {
		this.wnum = wnum;
	}
	public String getPnum() {
		return pnum;
	}
	public void setPnum(String pnum) {
		this.pnum = pnum;
	}
	public String getAnum() {
		return anum;
	}
	public void setAnum(String anum) {
		this.anum = anum;
	}
	
}
