package com.project.teacher.dto;

public class procPracticalDateDTO {
	private String subnum;
	private String pdate;
	
	
	public String getSubnum() {
		return subnum;
	}
	public void setSubnum(String subnum) {
		this.subnum = subnum;
	}
	public String getPdate() {
		return pdate;
	}
	public void setPdate(String pdate) {
		this.pdate = pdate;
	}
}
